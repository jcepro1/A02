﻿using System;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examensb
{
    class Vector
    {
        const int MAX = 50;
        private int[] v;
        private int n;

        public Vector()
        {
            n = 0;
            v = new int[MAX];
        }

        public void Cargar(int n1, int a, int b)
        {
            Random r = new Random();
            int i;
            n = n1;
            for (i = 1; i <= n; i++)
            {
                v[i] = r.Next(a, b);
            }
        }

        public void Cargar(int ele)
        {
            n++;
            v[n] = ele;
        }

        public void cargardato(int nele)
        {
            n = nele;
            int num = n;
            for (int i = 1; i <= num; i++)
            {
                v[i] = Conversions.ToInteger(Interaction.InputBox(" ", " "));
            }
        }

        public string Descargar()
        {
            string s = "";
            int i;
            for (i = 1; i <= n; i++)
            {
                s = s + v[i] + " | ";
            }
            return s;
        }

   

        //PREGUNTA 1

        public void pregunta1()
        {
            int i, b, a;
            NEnt ne = new NEnt();
            bool b1; a = 1; i = a; b = n;
            while (i <= b)
            {
                ne.cargar(v[i]);
                b1 = ne.VerifCapicua();
                while ((i <= b) && (!b1))
                {
                    i++;

                    if (i <= n)
                    {
                        ne.cargar(v[i]);
                        b1 = ne.VerifCapicua();

                    }

                }
                if (i <= b)
                {
                    ElimEle(i);
                    b = b - 1;
                }


            }
        }

        public void ElimEle(int p)
        {
            for (int i = p + 1; i <= n; i++)
            {
                v[i - 1] = v[i];

            }
            n = n - 1;
        }




        //PREGUNTA 2

        public void Pregunta2(Vector e, Vector f)
        {
            NEnt numero = new NEnt();
            OrdenarSegVec(1, n);
            int a, b;
            a = 1; b = n;
            for (int i = a; i <= b; i++)
            {
                numero.cargar(v[i]);

                if (numero.VerifCapicua())
                {
                    int ele = v[i];
                    int frec = frec_elem_segmento(v[i], a, b);
                    if (e.frecuencia(ele) == 0)
                    {
                        e.insertar(ele);
                        f.insertar(frec);
                    }

                }

            }
        }

        public void OrdenarSegVec(int a, int b)
        {
            checked
            {
                for (int i = a; i <= b; i++)
                {
                    int num = i + 1;
                    for (int j = num; j <= b; j++)
                    {
                        if (v[i] < v[j])
                        {
                            intercambiar(i, j);
                        }
                    }
                }
            }
        }
        public void intercambiar(int a, int b)
        {
            int aux;

            aux = v[a];
            v[a] = v[b];
            v[b] = aux;
        }
        public int frec_elem_segmento(int elem, int a, int b)
        {
            int c = 0;
            int num = a;
            int num2 = b;
            checked
            {
                for (int i = num; i <= num2; i++)
                {

                    if (elem == v[i])
                    {
                        c++;
                    }
                }
                return c;
            }
        }

        private void insertar(int ele)
        {
            n++;
            v[n] = ele;
        }

        public int frecuencia(int ele)
        {
            int c = 0;
            for (int i = 1; i <= n; i++)
            {
                if (v[i] == ele)
                {
                    c++;
                }
            }
            return c;
        }



    }
}
